<#
    Installs the Forescout SecureConnector compliance agent with the enrollment token
    injected via a generated MSI transform (.mst), never as a plain command-line property -
    `msiexec /v PROPERTY=value` is visible to anything that can read the process list
    (Get-Process, WMI, EDR telemetry) for as long as the installer runs. This is the same
    "no credentials on the command line" principle the project has applied everywhere else
    (x-api-key over headers, Bearer tokens over query strings).

    Not run for the Private category - Forescout compliance enforcement is a managed-device
    concept and Private devices are deliberately unmanaged.
#>

function Install-OsdCloudForescoutAgent {
    # Moved out of bundle.zip's own tools\ folder (2026-11-02) - osdcloud-provisioning (a
    # separate, self-managed Storage container) is now the source of truth for this file. The
    # WinPE-phase provisioning download is expected to have already placed it here, on the
    # offline OS drive, before the specialize pass runs this module.
    $msiPath = "C:\ProgramData\OsdCloud\Provisioning\SecureConnectorInstaller.msi"
    if (-not (Test-Path $msiPath)) {
        Write-Warning "$msiPath not found - Forescout install skipped. Check that the WinPE-phase provisioning download (osdcloud-provisioning container) ran and placed it there."
        return
    }

    Write-Host "Fetching Forescout enrollment token..." -ForegroundColor Cyan
    $tokenResponse = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/bootstrap/forescout-token"
    $token = $tokenResponse.token
    if (-not $token -or $token -eq "REPLACE_WITH_REAL_FORESCOUT_ENROLLMENT_TOKEN") {
        Write-Warning "Forescout enrollment token is a placeholder (forescout-enrollment-token in Key Vault has not been set to a real value) - Forescout install skipped."
        return
    }

    # NOTE: "ENROLLMENT_TOKEN" is this project's best-effort guess at the MSI property
    # SecureConnectorInstaller.msi expects - confirm the real property name against
    # Forescout's SecureConnector deployment guide before relying on this in production,
    # and update $tokenPropertyName below if it differs.
    $tokenPropertyName = "ENROLLMENT_TOKEN"

    $transformPath = Join-Path $env:TEMP "forescout-token.mst"
    New-OsdCloudMsiTransform -MsiPath $msiPath -TransformPath $transformPath -Properties @{ $tokenPropertyName = $token }

    Write-Host "Installing Forescout SecureConnector..." -ForegroundColor Cyan
    $logPath = Join-Path $env:ProgramData "OsdCloud\forescout-install.log"
    $process = Start-Process -FilePath "msiexec.exe" `
        -ArgumentList "/i", "`"$msiPath`"", "TRANSFORMS=`"$transformPath`"", "/quiet", "/norestart", "/log", "`"$logPath`"" `
        -Wait -PassThru

    Remove-Item $transformPath -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -ne 0) {
        throw "Forescout SecureConnector install failed with exit code $($process.ExitCode). See $logPath."
    }
    Write-Host "Forescout SecureConnector installed." -ForegroundColor Green
}

<#
    Generates a minimal MSI transform that sets the given Property table values, via the
    Windows Installer COM API - the only way to set an MSI property without it appearing on
    the msiexec command line.
#>
function New-OsdCloudMsiTransform {
    param(
        [Parameter(Mandatory)][string]$MsiPath,
        [Parameter(Mandatory)][string]$TransformPath,
        [Parameter(Mandatory)][hashtable]$Properties
    )

    $workingCopyPath = Join-Path $env:TEMP "forescout-working.msi"
    Copy-Item -Path $MsiPath -Destination $workingCopyPath -Force

    $installer = New-Object -ComObject WindowsInstaller.Installer
    $referenceDb = $installer.OpenDatabase($MsiPath, 0)      # msiOpenDatabaseModeReadOnly
    $workingDb = $installer.OpenDatabase($workingCopyPath, 1) # msiOpenDatabaseModeTransact

    foreach ($propertyName in $Properties.Keys) {
        $propertyValue = ($Properties[$propertyName] -replace "'", "''")
        $existsView = $workingDb.OpenView("SELECT * FROM Property WHERE Property='$propertyName'")
        $existsView.Execute($null)
        $exists = $null -ne $existsView.Fetch()
        $existsView.Close()

        if ($exists) {
            $updateView = $workingDb.OpenView("UPDATE Property SET Value='$propertyValue' WHERE Property='$propertyName'")
        } else {
            $updateView = $workingDb.OpenView("INSERT INTO Property (Property, Value) VALUES ('$propertyName', '$propertyValue')")
        }
        $updateView.Execute($null)
        $updateView.Close()
    }

    $workingDb.GenerateTransform($referenceDb, $TransformPath)
    $workingDb.CreateTransformSummaryInfo($referenceDb, $TransformPath, 0, 0)

    Remove-Item $workingCopyPath -Force -ErrorAction SilentlyContinue
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($installer) | Out-Null
}

Export-ModuleMember -Function Install-OsdCloudForescoutAgent
