<#
    Applies the technician-chosen language (independent field) and the keyboard derived from
    the chosen company's site (api/Data/location-lookup-sites.json). The base image always
    installs as en-US; the language pack + locale settings are layered on here, post-imaging,
    so a single boot image serves every site/company without per-site WIMs.

    Time zone defaults to the same site but can be overridden independently - the technician
    picks it in the HTA (defaulting to the company's site, but selectable from the full
    Microsoft time zone list), so whatever they picked is what gets applied here, not
    necessarily the site's own value.
#>

function Get-OsdCloudSiteCodeForCompany {
    param([string]$CompanyId)

    if (-not $CompanyId) { return $null }

    $companies = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/companies"
    $company = $companies | Where-Object { $_.id -eq $CompanyId }
    if ($company) { return $company.siteCode }
    return $null
}

function Install-OsdCloudLanguage {
    param(
        [Parameter(Mandatory)][string]$LanguageCode,
        [string]$SiteCode,
        [string]$TimeZoneId
    )

    $languages = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/languages"
    $language = $languages | Where-Object { $_.code -eq $LanguageCode }
    if (-not $language) {
        Write-Warning "Language code '$LanguageCode' was not found in the catalog; skipping language pack install."
        return
    }

    if ($language.code -ne "en-US") {
        Write-Host "Installing language pack $($language.languagePack)..." -ForegroundColor Cyan
        Add-WindowsCapability -Online -Name $language.languagePack | Out-Null
    }

    $languageList = New-WinUserLanguageList -Language $language.code
    Set-WinUserLanguageList -LanguageList $languageList -Force
    Set-SystemPreferredUILanguage -Language $language.code
    Set-WinUILanguageOverride -Language $language.code

    if ($SiteCode) {
        $sites = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/locations"
        $site = $sites | Where-Object { $_.siteCode -eq $SiteCode }
        if ($site) {
            $effectiveTimeZoneId = if ($TimeZoneId) { $TimeZoneId } else { $site.windowsTimeZoneId }
            Write-Host "Applying keyboard $($site.keyboard) and timezone $effectiveTimeZoneId for site $SiteCode..." -ForegroundColor Cyan
            Set-WinHomeLocation -GeoId $site.geoId
            Set-WinDefaultInputMethodOverride -InputTip $site.keyboardLocale
            Set-TimeZone -Id $effectiveTimeZoneId
        } else {
            Write-Warning "Site code '$SiteCode' was not found in the catalog; keyboard left at image defaults."
            if ($TimeZoneId) {
                Write-Host "Applying technician-selected timezone $TimeZoneId..." -ForegroundColor Cyan
                Set-TimeZone -Id $TimeZoneId
            }
        }
    } elseif ($TimeZoneId) {
        Write-Host "Applying technician-selected timezone $TimeZoneId..." -ForegroundColor Cyan
        Set-TimeZone -Id $TimeZoneId
    }
}

Export-ModuleMember -Function Install-OsdCloudLanguage, Get-OsdCloudSiteCodeForCompany
