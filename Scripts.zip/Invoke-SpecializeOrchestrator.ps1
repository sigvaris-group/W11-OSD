<#
    Runs once via SetupComplete.cmd during the specialize pass. Reads the config dropped by
    scripts/BootImage/OsdCloud.Provisioning.psm1 during WinPE and finishes the join/enrollment
    work that can only happen once the real OS is running (hardware hash collection, Hybrid
    domain join, language pack install).

    EntraID-category devices need no explicit join step here: Autopilot + the Intune ESP
    (configured per docs/autopilot-epm-setup.md) handle the actual Entra join/enrollment once
    the device reaches OOBE with its hash already registered. This script's job for that path
    is purely to get the hash registered before OOBE starts.
#>

$ErrorActionPreference = "Stop"
$ConfigPath = Join-Path $env:ProgramData "OsdCloud\deployment-config.json"

Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.ApiClient.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Autopilot.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Localization.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.HybridJoin.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Branding.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Forescout.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Office.psm1") -Force
Import-Module (Join-Path $PSScriptRoot "OsdCloud.Specialize.Cleanup.psm1") -Force

if (-not (Test-Path $ConfigPath)) {
    throw "Deployment config not found at $ConfigPath - WinPE provisioning did not complete correctly."
}

$config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
Initialize-OsdCloudSpecializeApiClient -BaseUrl $config.apiBaseUrl -ApiKey $config.apiKey

Write-Host "Specialize phase starting for $($config.hostname) (joinType=$($config.joinType), category=$($config.deviceCategory))" -ForegroundColor Cyan

try {
    $siteCode = Get-OsdCloudSiteCodeForCompany -CompanyId $config.companyId
    Install-OsdCloudLanguage -LanguageCode $config.languageCode -SiteCode $siteCode -TimeZoneId $config.timeZoneId
    Enable-OsdCloudLegacyNetFx3 -Hostname $config.hostname

    # Branding/hardening and cleanup are generic OS polish, not tied to management state -
    # every category gets them, including Private.
    Set-OsdCloudBranding
    Remove-OsdCloudUnwantedApps

    if ($config.deviceCategory -eq "Private") {
        Write-Host "Private category - skipping Autopilot registration, domain join, Forescout, and M365 Apps." -ForegroundColor Yellow
    } else {
        Register-OsdCloudAutopilotDevice -DeploymentCode $config.deploymentCode | Out-Null

        if ($config.joinType -eq "Hybrid") {
            if (-not $siteCode) {
                throw "Cannot Hybrid-join without a resolved site code (companyId=$($config.companyId))."
            }
            Join-OsdCloudHybridDomain -Hostname $config.hostname -SiteCode $siteCode
        }
        # EntraId joinType: Autopilot ESP handles the actual join at OOBE - nothing more to do here.

        Install-OsdCloudForescoutAgent

        if ($config.deviceCategory -eq "Teams") {
            # Teams Rooms devices don't need the full M365 Office suite - installing the Pro
            # Management agent is what gets them into the Teams Rooms Pro Management Portal
            # (registration itself is automatic, no API call - see the function's own
            # header comment).
            Install-OsdCloudTeamsRoomsProAgent
        }
        # Office/M365 Apps is no longer installed here (removed 2026-11-02) - whether to
        # install it is a selection the HTA already makes as part of its app picker, assigned
        # via Intune like any other selected app, not a bundle.zip specialize-phase step.
    }

    Clear-OsdCloudStagingArtifacts

    Invoke-OsdCloudSpecializeApi -Method POST -Path "/api/deployments/$($config.deploymentCode)/status" -Body @{ status = "Completed" } | Out-Null
    Write-Host "Specialize phase completed successfully." -ForegroundColor Green
} catch {
    Write-Error "Specialize phase failed: $($_.Exception.Message)"
    try {
        Invoke-OsdCloudSpecializeApi -Method POST -Path "/api/deployments/$($config.deploymentCode)/status" `
            -Body @{ status = "Failed"; errorMessage = $_.Exception.Message } | Out-Null
    } catch {
        Write-Warning "Could not report failure status back to the API: $($_.Exception.Message)"
    }
    throw
}
