<#
    Windows 11 branding/hardening tweaks ported forward from the production scripts this
    project replaces (OLDSCRIPTS/W11_Setup.ps1) - these are generic OS polish, not tied to
    join type or device category, so they run for every category including Private.
#>

function Set-OsdCloudBranding {
    Write-Host "Applying branding/hardening tweaks..." -ForegroundColor Cyan

    # Hide the widgets taskbar icon. UCPD blocks direct registry edits on 24H2+
    # (see https://kolbi.cz/blog/2024/04/03/userchoice-protection-driver-ucpd-sys/) -
    # copying reg.exe to a new name sidesteps the driver's path-based block.
    $ci = Get-ComputerInfo
    if ($ci.OsBuildNumber -ge 26100) {
        $tempRegExe = Join-Path $env:TEMP "reg1.exe"
        Copy-Item -Path (Get-Command reg.exe).Source -Destination $tempRegExe -Force
        & $tempRegExe add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f /reg:64 | Out-Null
        Remove-Item $tempRegExe -Force -ErrorAction SilentlyContinue
    } else {
        reg.exe add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f /reg:64 | Out-Null
    }

    # Disable Widgets outright (greys out the Settings toggle too).
    if (-not (Test-Path "HKLM:\Software\Policies\Microsoft\Dsh")) {
        New-Item -Path "HKLM:\Software\Policies\Microsoft\Dsh" | Out-Null
    }
    Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh" -Name "DisableWidgetsOnLockScreen" -Value 1
    Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh" -Name "DisableWidgetsBoard" -Value 1
    Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Dsh" -Name "AllowNewsAndInterests" -Value 0

    # Edge desktop shortcut roams into OneDrive and creates clutter - turn it off.
    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v DisableEdgeDesktopShortcutCreation /t REG_DWORD /d 1 /f /reg:64 | Out-Null
    reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\EdgeUpdate" /v "CreateDesktopShortcutDefault" /t REG_DWORD /d 0 /f /reg:64 | Out-Null

    # Personal Teams ships provisioned on new images - remove it in favor of the managed one.
    Get-AppxPackage -Name MicrosoftTeams -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue

    reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Network\NewNetworkWindowOff" /f | Out-Null
    reg.exe add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v StartShownOnUpgrade /t REG_DWORD /d 1 /f | Out-Null
    reg.exe add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{2cc5ca98-6485-489a-920e-b3e88a6ccce3}" /t REG_DWORD /d 1 /f | Out-Null
    reg.exe add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v DisableSpotlightCollectionOnDesktop /t REG_DWORD /d 1 /f | Out-Null

    # Windows Update policy keys that conflict with Windows Autopatch, if present from a prior image.
    $conflictingUpdateKeys = @(
        @{ Name = "DoNotConnectToWindowsUpdateInternetLocations"; Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\" }
        @{ Name = "DisableWindowsUpdateAccess"; Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\" }
        @{ Name = "WUServer"; Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\" }
        @{ Name = "UseWUServer"; Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\" }
        @{ Name = "NoAutoUpdate"; Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\" }
    )
    foreach ($setting in $conflictingUpdateKeys) {
        if ((Get-Item $setting.Path -ErrorAction Ignore).Property -contains $setting.Name) {
            Remove-ItemProperty -Path $setting.Path -Name $setting.Name
        }
    }

    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOwner /t REG_SZ /d "Global IT" /f /reg:64 | Out-Null
    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOrganization /t REG_SZ /d "SIGVARIS GROUP" /f /reg:64 | Out-Null

    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "SIGVARIS GROUP" /f /reg:64 | Out-Null
    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "Autopilot" /f /reg:64 | Out-Null
    reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "https://sigvarisitcustomercare.saasiteu.com/Account/Login?ProviderName=AAD" /f /reg:64 | Out-Null
    # Moved out of bundle.zip's own tools\ folder (2026-11-02) - osdcloud-provisioning (a
    # separate, self-managed Storage container) is now the source of truth for this file. The
    # WinPE-phase provisioning download is expected to have already placed it here, on the
    # offline OS drive, before the specialize pass runs this module.
    $logoPath = "C:\ProgramData\OsdCloud\Provisioning\sigvaris.bmp"
    if (Test-Path $logoPath) {
        Copy-Item $logoPath -Destination "C:\Windows\sigvaris.bmp" -Force
        reg.exe add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Logo /t REG_SZ /d "C:\Windows\sigvaris.bmp" /f /reg:64 | Out-Null
    } else {
        Write-Warning "$logoPath not found - OEM logo branding skipped. Check that the WinPE-phase provisioning download (osdcloud-provisioning container) ran and placed it there."
    }

    # Autopilot v2 extra pages (too late to do anything about the EULA itself).
    $oobePath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE"
    New-ItemProperty -Path $oobePath -Name "DisablePrivacyExperience" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $oobePath -Name "DisableVoice" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $oobePath -Name "PrivacyConsentStatus" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $oobePath -Name "ProtectYourPC" -Value 3 -PropertyType DWord -Force | Out-Null

    $policyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    New-ItemProperty -Path $policyPath -Name "EnableFirstLogonAnimation" -Value 0 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $policyPath -Name "DelayedDesktopSwitch" -Value 0 -PropertyType DWord -Force | Out-Null

    # KB5058411 regression workaround - disable then re-enable to force a clean re-registration.
    Disable-WindowsOptionalFeature -Online -FeatureName Printing-PrintToPDFServices-Features -NoRestart -ErrorAction SilentlyContinue | Out-Null
    Enable-WindowsOptionalFeature -Online -FeatureName Printing-PrintToPDFServices-Features -NoRestart -ErrorAction SilentlyContinue | Out-Null
}

<#
    A handful of North American sites still need .NET Framework 3.5 for a local line-of-
    business app - keyed off the hostname's site-code prefix, same convention as every
    other site-derived setting in this project (api/Data/location-lookup-sites.json).
#>
function Enable-OsdCloudLegacyNetFx3 {
    param([Parameter(Mandatory)][string]$Hostname)

    $sitesNeedingNetFx3 = @("SICAMO", "SIUSGA", "SIUSMI")
    $sitePrefix = $Hostname.Substring(0, [Math]::Min(6, $Hostname.Length))

    if ($sitesNeedingNetFx3 -contains $sitePrefix) {
        Write-Host "Enabling .NET Framework 3.5 for site $sitePrefix..." -ForegroundColor Cyan
        Enable-WindowsOptionalFeature -Online -FeatureName NetFx3 -NoRestart | Out-Null
    }
}

<#
    Default appx removal list, ported from OLDSCRIPTS/W11_Setup.ps1's OSDeploy.OOBEDeploy.json
    (the duplicate/malformed entries in the original have been de-duplicated and fixed here).
#>
function Remove-OsdCloudUnwantedApps {
    Write-Host "Removing unwanted provisioned apps..." -ForegroundColor Cyan

    $appsToRemove = @(
        "*ActiproSoftwareLLC*", "*AdobeSystemsIncorporated.AdobePhotoshopExpress*", "Disney.37853FC22B2CE",
        "*Duolingo-LearnLanguagesforFree*", "*EclipseManager*", "*PandoraMediaInc*", "*CandyCrush*",
        "*BubbleWitch3Saga*", "*Wunderlist*", "*Flipboard*", "*Twitter*", "*Facebook*", "*Spotify*",
        "*Minecraft*", "*Royal Revolt*", "*Sway*", "*Speed Test*", "*Dolby*", "*Office*", "*Disney*",
        "clipchamp.clipchamp", "*gaming*", "MicrosoftCorporationII.MicrosoftFamily", "C27EB4BA.DropboxOEM",
        "*DevHome*", "Microsoft.549981C3F5F10", "Microsoft.BingWeather", "Microsoft.BingNews",
        "Microsoft.Copilot", "Microsoft.GamingApp", "Microsoft.GetHelp", "Microsoft.Getstarted",
        "Microsoft.Messaging", "Microsoft.Microsoft3DViewer", "Microsoft.MicrosoftOfficeHub",
        "Microsoft.MicrosoftSolitaireCollection", "Microsoft.MicrosoftStickyNotes", "Microsoft.MSPaint",
        "Microsoft.MixedReality.Portal", "Microsoft.NetworkSpeedTest", "Microsoft.News",
        "Microsoft.Office.Lens", "Microsoft.OneConnect", "Microsoft.People", "Microsoft.PowerAutomateDesktop",
        "Microsoft.Print3D", "Microsoft.SkypeApp", "SpotifyAB.SpotifyMusic", "Microsoft.StorePurchaseApp",
        "MicrosoftTeams", "Microsoft.Todos", "microsoft.windowscommunicationsapps",
        "Microsoft.WindowsFeedbackHub", "Microsoft.WindowsMaps", "Microsoft.WindowsSoundRecorder",
        "Microsoft.Xbox.TCUI", "Microsoft.XboxGameOverlay", "Microsoft.XboxGamingOverlay",
        "Microsoft.XboxIdentityProvider", "Microsoft.XboxSpeechToTextOverlay", "Microsoft.YourPhone",
        "Microsoft.ZuneMusic", "Microsoft.ZuneVideo"
    )

    foreach ($appPattern in $appsToRemove) {
        Get-AppxPackage -Name $appPattern -AllUsers -ErrorAction SilentlyContinue |
            Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
    }
}

Export-ModuleMember -Function Set-OsdCloudBranding, Enable-OsdCloudLegacyNetFx3, Remove-OsdCloudUnwantedApps
