<#
    Hybrid Azure AD Join, ported forward from the real production script
    (OLDSCRIPTS/Computer_DomainJoin.ps1): a live `Add-Computer` call during specialize phase,
    using a domain-join bind account fetched from a dedicated Key Vault
    (itsp-osdcloud-adjoin-kv, separate from the main itsp-osdcloud-kv because this
    credential is domain-admin-adjacent) via the API's x-api-key-gated bootstrap endpoint.

    This replaces an earlier Offline-Domain-Join-blob + on-prem relay worker design, which
    was built specifically to avoid ever handing a device a live domain credential. The
    live-credential approach was chosen instead because it's what's actually running in
    production today - see CLAUDE.md for the trade-off this accepts.
#>

<#
    The OU path lives in the same site catalog company.md feeds (api/Data/location-lookup-sites.json
    -> hybridOuPath), not hardcoded here - that catalog is the single place to fix a site's
    OU without touching this script. SICHWI (the one site code newer than the production OU
    list this was ported from) carries the same template as every other site there, but has
    NOT been verified against the real directory.
#>
function Get-OsdCloudAdJoinOuPath {
    param([Parameter(Mandatory)][string]$SiteCode)

    $sites = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/locations"
    $site = $sites | Where-Object { $_.siteCode -eq $SiteCode }
    if (-not $site -or -not $site.hybridOuPath) {
        throw "No hybridOuPath found for site '$SiteCode' in the location catalog (api/Data/location-lookup-sites.json)."
    }
    return $site.hybridOuPath
}

<#
    The configured server (ad-join-server in Key Vault) is a single named domain
    controller - a single point of failure if that specific box is down, being patched, or
    unreachable from a given site's network. Falls back to DNS/site-aware DC discovery
    (`nltest /dsgetdc`, built into Windows, no RSAT required) so a join can still succeed
    against whichever DC is actually reachable.
#>
function Get-OsdCloudReachableDomainController {
    param(
        [Parameter(Mandatory)][string]$PreferredServer,
        [Parameter(Mandatory)][string]$Domain
    )

    $preferredReachable = Test-NetConnection -ComputerName $PreferredServer -Port 389 -InformationLevel Quiet -WarningAction SilentlyContinue
    if ($preferredReachable) {
        Write-Host "Preferred domain controller $PreferredServer is reachable." -ForegroundColor Cyan
        return $PreferredServer
    }

    Write-Warning "Preferred domain controller $PreferredServer is not reachable on LDAP (389) - searching for another one via DNS/site-aware discovery."

    $nltestOutput = & nltest.exe "/dsgetdc:$Domain" 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "nltest /dsgetdc:$Domain failed (exit $LASTEXITCODE): $($nltestOutput -join ' ')"
        return $null
    }

    $dcLine = $nltestOutput | Select-String -Pattern '^\s*DC:\s*\\\\(.+)$'
    if (-not $dcLine) {
        Write-Warning "Could not parse a domain controller name out of nltest output."
        return $null
    }

    $discoveredServer = $dcLine.Matches[0].Groups[1].Value.Trim()
    Write-Host "Discovered domain controller $discoveredServer via DNS/site-aware lookup." -ForegroundColor Cyan
    return $discoveredServer
}

function Join-OsdCloudHybridDomain {
    param(
        [Parameter(Mandatory)][string]$Hostname,
        [Parameter(Mandatory)][string]$SiteCode
    )

    Write-Host "Starting services required for domain join during specialize phase..." -ForegroundColor Cyan
    foreach ($serviceName in @("LanmanWorkstation", "Bowser", "Mrxsmb20", "Nsi")) {
        Start-Service -Name $serviceName -ErrorAction SilentlyContinue
    }

    Write-Host "Fetching domain-join credential..." -ForegroundColor Cyan
    $cred = Invoke-OsdCloudSpecializeApi -Method GET -Path "/api/bootstrap/domain-join-credential"
    if (-not $cred.password -or $cred.password -eq "REPLACE_WITH_REAL_AD_JOIN_PASSWORD") {
        throw "ad-join-password in itsp-osdcloud-adjoin-kv is still a placeholder - cannot join $Hostname to the domain."
    }

    $server = Get-OsdCloudReachableDomainController -PreferredServer $cred.server -Domain $cred.domain
    if (-not $server) {
        throw "Could not reach $($cred.server) or discover any other domain controller for $($cred.domain). Check network connectivity to the corporate network before retrying."
    }

    $securePassword = ConvertTo-SecureString $cred.password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($cred.username, $securePassword)
    $ouPath = Get-OsdCloudAdJoinOuPath -SiteCode $SiteCode

    Write-Host "Joining $Hostname to $($cred.domain) via $server, OU $ouPath..." -ForegroundColor Cyan
    Add-Computer -DomainName $cred.domain -Server $server -Credential $credential -OUPath $ouPath -PassThru -Force -Verbose
    Write-Host "Domain join completed." -ForegroundColor Green
}

Export-ModuleMember -Function Join-OsdCloudHybridDomain, Get-OsdCloudAdJoinOuPath, Get-OsdCloudReachableDomainController
