<#
    Same shared-key API client pattern as scripts/BootImage/OsdCloud.ApiClient.psm1, but
    this copy runs post-imaging inside the real (non-WinPE) OS during the specialize pass,
    where Invoke-RestMethod is available - no need for the Msxml2.XMLHTTP COM workaround
    WinPE requires.
#>

$script:ApiBaseUrl = $null
$script:ApiKey = $null

function Initialize-OsdCloudSpecializeApiClient {
    param([Parameter(Mandatory)][string]$BaseUrl, [Parameter(Mandatory)][string]$ApiKey)
    $script:ApiBaseUrl = $BaseUrl.TrimEnd('/')
    $script:ApiKey = $ApiKey
}

function Invoke-OsdCloudSpecializeApi {
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Path,
        $Body
    )

    $uri = "$script:ApiBaseUrl$Path"
    $headers = @{ "x-api-key" = $script:ApiKey }

    $params = @{
        Method  = $Method
        Uri     = $uri
        Headers = $headers
    }

    if ($null -ne $Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 10)
        $params.ContentType = "application/json"
    }

    return Invoke-RestMethod @params
}

Export-ModuleMember -Function Initialize-OsdCloudSpecializeApiClient, Invoke-OsdCloudSpecializeApi
