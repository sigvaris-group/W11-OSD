<#
    Installs Microsoft 365 Apps via the Office Deployment Tool, ported forward from
    OLDSCRIPTS/W11_OSDStart.ps1's configuration.xml. Not run for the Private category -
    those devices get a stock consumer OOBE, not a managed app set.
#>

function Install-OsdCloudM365Apps {
    param([Parameter(Mandatory)][string]$DisplayLanguage)

    $setupExePath = Join-Path $PSScriptRoot "tools\setup.exe"
    if (-not (Test-Path $setupExePath)) {
        Write-Warning "tools\setup.exe (Office Deployment Tool) not found in the Bundle package - M365 Apps install skipped. See scripts/Bundle/tools/README.md."
        return
    }

    $configDir = Join-Path $env:ProgramData "OSDeploy\M365"
    New-Item -ItemType Directory -Path $configDir -Force | Out-Null
    $configPath = Join-Path $configDir "configuration.xml"

    $officeXml = @"
<Configuration ID="44ad4a5b-8ca2-4b1d-9120-4ccb79ab01bc">
  <Info Description="M365 Enterprise without Access" />
  <Add OfficeClientEdition="64" Channel="MonthlyEnterprise">
    <Product ID="O365ProPlusRetail">
      <Language ID="$DisplayLanguage" />
      <Language ID="MatchOS" />
      <ExcludeApp ID="Access" />
      <ExcludeApp ID="Groove" />
      <ExcludeApp ID="Lync" />
      <ExcludeApp ID="Bing" />
    </Product>
  </Add>
  <Property Name="SharedComputerLicensing" Value="0" />
  <Property Name="FORCEAPPSHUTDOWN" Value="TRUE" />
  <Property Name="DeviceBasedLicensing" Value="0" />
  <Property Name="SCLCacheOverride" Value="0" />
  <Property Name="TenantId" Value="ef4411a0-98e1-423e-b88f-17bde7516216" />
  <Updates Enabled="TRUE" />
  <AppSettings>
    <Setup Name="Company" Value="SIGVARIS GROUP" />
    <User Key="software\microsoft\office\16.0\excel\options" Name="defaultformat" Value="51" Type="REG_SZ" App="excel16" Id="L_SaveExcelfilesas" />
    <User Key="software\microsoft\office\16.0\powerpoint\options" Name="defaultformat" Value="27" Type="REG_DWORD" App="ppt16" Id="L_SavePowerPointfilesas" />
    <User Key="software\microsoft\office\16.0\word\options" Name="defaultformat" Value="" Type="REG_SZ" App="word16" Id="L_SaveWordfilesas" />
  </AppSettings>
  <Display Level="None" AcceptEULA="TRUE" />
</Configuration>
"@
    Set-Content -Path $configPath -Value $officeXml -Encoding UTF8

    Write-Host "Installing Microsoft 365 Apps ($DisplayLanguage)..." -ForegroundColor Cyan
    $process = Start-Process -FilePath $setupExePath -ArgumentList "/configure", "`"$configPath`"" -Wait -PassThru
    if ($process.ExitCode -ne 0) {
        throw "Office Deployment Tool exited with code $($process.ExitCode)."
    }
    Write-Host "Microsoft 365 Apps installed." -ForegroundColor Green
}

<#
    Teams Rooms on Windows devices don't need the full M365 Office suite. What actually
    makes a device show up in the Teams Rooms Pro Management Portal (the successor to the
    old Teams admin center device list - Microsoft Graph's teamworkDevice API is being
    retired with "no plans to support Graph APIs for Teams Devices") is installing the Pro
    Management agent (ManagedRoomsInstaller.msi) and signing in with the room's resource
    account - registration is automatic, within 5-10 minutes, with no API call involved.
    See https://learn.microsoft.com/en-us/microsoftteams/rooms/enroll-a-device.

    This installs that agent only. The actual Teams Rooms meeting-room client experience
    (hardware/peripheral integration, room console UI) is a separate, OEM/certified-hardware
    concern this project's specialize phase was never scoped to cover - assumed to already
    exist on the hardware this runs on, or to be handled outside this pipeline.
#>
function Install-OsdCloudTeamsRoomsProAgent {
    $installerPath = Join-Path $PSScriptRoot "tools\TeamsRoomsProAgent\ManagedRoomsInstaller.msi"
    if (-not (Test-Path $installerPath)) {
        Write-Warning "tools\TeamsRoomsProAgent\ManagedRoomsInstaller.msi not found in the Bundle package - Teams Rooms Pro Management agent install skipped. See scripts/Bundle/tools/README.md."
        return
    }

    Write-Host "Installing the Teams Rooms Pro Management agent..." -ForegroundColor Cyan
    $logPath = Join-Path $env:ProgramData "OsdCloud\teams-rooms-pro-agent-install.log"
    $process = Start-Process -FilePath "msiexec.exe" `
        -ArgumentList "/i", "`"$installerPath`"", "/quiet", "/norestart", "/log", "`"$logPath`"" `
        -Wait -PassThru
    if ($process.ExitCode -ne 0) {
        throw "Teams Rooms Pro Management agent install failed with exit code $($process.ExitCode). See $logPath."
    }
    Write-Host "Teams Rooms Pro Management agent installed - the device registers in the Pro Management Portal automatically once the room's resource account signs into Teams." -ForegroundColor Green
}

Export-ModuleMember -Function Install-OsdCloudM365Apps, Install-OsdCloudTeamsRoomsProAgent
