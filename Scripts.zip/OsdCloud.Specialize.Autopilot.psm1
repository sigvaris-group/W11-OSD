<#
    Collects this device's hardware hash and reports it to the API, which owns the actual
    Graph import call (see api/Services/AutopilotRegistrationService.cs). Never runs for
    the Private category - those devices are deliberately not Autopilot-registered.
#>

function Get-OsdCloudHardwareHash {
    $session = New-CimSession
    $hash = (Get-CimInstance -CimSession $session -Namespace root/cimv2/mdm/dmmap -Class MDM_DevDetail_Ext01 -Filter "InstanceID='Ext' AND ParentID='./DevDetail'").DeviceHardwareData
    $serial = (Get-CimInstance -CimSession $session -ClassName Win32_BIOS).SerialNumber
    Remove-CimSession $session

    return [pscustomobject]@{
        SerialNumber = $serial
        HardwareHash = $hash
    }
}

function Register-OsdCloudAutopilotDevice {
    param([Parameter(Mandatory)][string]$DeploymentCode)

    $info = Get-OsdCloudHardwareHash
    if (-not $info.HardwareHash) {
        throw "Could not read the device hardware hash (MDM_DevDetail_Ext01). Autopilot registration cannot proceed."
    }

    $request = @{ serialNumber = $info.SerialNumber; hardwareHash = $info.HardwareHash }
    $result = Invoke-OsdCloudSpecializeApi -Method POST -Path "/api/deployments/$DeploymentCode/autopilot-hash" -Body $request

    if (-not $result.registered) {
        throw "Autopilot registration failed: $($result.detail)"
    }

    Write-Host "Autopilot import submitted for serial $($info.SerialNumber)." -ForegroundColor Green
    return $result
}

Export-ModuleMember -Function Get-OsdCloudHardwareHash, Register-OsdCloudAutopilotDevice
