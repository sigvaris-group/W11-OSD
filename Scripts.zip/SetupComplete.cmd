@echo off
REM Runs once, automatically, at the end of Windows Setup (specialize pass).
REM Staged here by OsdCloud.Provisioning.psm1 during WinPE imaging.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ProgramData%\OsdCloud\Bundle\Invoke-SpecializeOrchestrator.ps1" *>> "%ProgramData%\OsdCloud\specialize.log"
