<#
    Removes deployment staging artifacts once specialize phase has finished, ported forward
    from OLDSCRIPTS/W11_CleanUP.ps1. Runs for every category, including Private.
#>

function Clear-OsdCloudStagingArtifacts {
    Write-Host "Cleaning up deployment staging artifacts..." -ForegroundColor Cyan

    Remove-Item C:\Windows\Setup\Scripts\*.* -Exclude *.TAG -Force -ErrorAction SilentlyContinue

    if (Test-Path "C:\OSDCloud\Logs") {
        Move-Item "C:\OSDCloud\Logs" -Destination "C:\ProgramData\OSDeploy" -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path "C:\OSDCloud") { Remove-Item "C:\OSDCloud" -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path "C:\Drivers") { Remove-Item "C:\Drivers" -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path "C:\Intel") { Remove-Item "C:\Intel" -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path "C:\ProgramData\OSDeploy\WiFi") { Remove-Item "C:\ProgramData\OSDeploy\WiFi" -Recurse -Force -ErrorAction SilentlyContinue }

    # Deliberately NOT removing C:\ProgramData\OsdCloud\Bundle here - this orchestrator
    # script and every module it imported are running from inside that folder right now.
    # Schedule its removal for the next boot instead, once nothing has it open.
    $cleanupCommand = "timeout /t 5 >nul & rmdir /s /q `"C:\ProgramData\OsdCloud\Bundle`""
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $cleanupCommand -WindowStyle Hidden
}

Export-ModuleMember -Function Clear-OsdCloudStagingArtifacts
